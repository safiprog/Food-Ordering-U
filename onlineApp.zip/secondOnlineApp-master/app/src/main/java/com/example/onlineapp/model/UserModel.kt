package com.example.onlineapp.model

data class UserModel(
     val userName:String?="",
     val userPhoneNumber:String?="",
     val roomNo:String?="",
     val state:String?="",
     val city:String?="",
     val pincode:String?="",




)
