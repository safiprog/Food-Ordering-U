package com.example.onlineapp.model

data class AllOrderModel(
    val name:String?="",
    val orderId:String?="",
    val price:String?="",
    val productId:String?="",
    val status:String?="",
    val userId:String?="",
)
