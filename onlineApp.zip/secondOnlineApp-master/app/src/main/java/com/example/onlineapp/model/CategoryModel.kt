package com.example.onlineapp.model

class CategoryModel(
    var cate:String?="",
    var img:String?=""
){

}